# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 17:38:53 2019

@author: srn
"""
import pandas as pd
import numpy as np
df = pd.DataFrame({'key1' : ['a', 'a', 'b', 'b', 'a'],
                   'key2' : ['one', 'two', 'one', 'two', 'one'],
                   'data1' : np.random.randn(5),
                   'data2' : np.random.randn(5)})
grouped = df.groupby('key1')
grouped['data1'].quantile(0.9)
def peak_to_peak(arr):
    return arr.max() - arr.min()
grouped['data1'].agg(peak_to_peak)
print(grouped.describe())
