package com.parkinglot.util;

import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.parkinglot.dao.Vehicle;
import com.parkinglot.factory.VehicleFactory;

public class ParkingUtility {
	private static Set<Integer> emptySlotList = new TreeSet<>();
	private static Map<Integer, Vehicle> carSlotList;
	private static Vehicle car;
	private static int lotSize;
	private static int j = 1;
	private static Integer slotNumber;
	private static int temp;
	public static void createParkingLot(String[] consoleInput) {
		lotSize = Integer.parseInt(consoleInput[1]);
		carSlotList = new TreeMap<>();
		System.out.println("Created a parking lot with " + lotSize + " slots");
	}

	public static void parkVehicle(String[] consoleInput) {
		car = VehicleFactory.getVehicle("car", consoleInput[1], consoleInput[2]);
		try{temp=emptySlotList.iterator().next();}
		catch(NoSuchElementException e) {
		}
		if (carSlotList.get(j) == null && j <= lotSize) {
			carSlotList.put(j, car);
			System.out.println("Allocated slot number: " + j);
			j++;
		}else if(carSlotList.get(temp) == null && temp<=lotSize) {
			carSlotList.put(temp, car);
			emptySlotList.remove(temp);
			System.out.println("Allocated slot number: " + temp);
		} else {
			System.err.println("Sorry, parking lot is full");
		}
	}

	public static void leaveVehicle(String[] consoleInput) {
		slotNumber = Integer.parseInt(consoleInput[1]);
		if (carSlotList.get(slotNumber) != null) {
			carSlotList.remove(slotNumber);
			emptySlotList.add(slotNumber);
			//System.out.println("emptySlotList"+emptySlotList);
			System.out.println("Slot number " + slotNumber + " is free");
		}
	}

	public static void getVehicleStatus(String[] consoleInput) {
		if (carSlotList.isEmpty() != true) {
			System.err.println("Slot No. " + " Registration No." + " Color");
			System.out.println("                                      ");
			for (Map.Entry<Integer, Vehicle> entry : carSlotList.entrySet()) {
				System.out.println(entry.getKey() + "" + entry.getValue());
			}
		} else {
			System.err.println("Not found");
		}
	}

	public static void getRegNumberForGivenVehicleColor(String[] consoleInput) {
		if (carSlotList.isEmpty() != true) {
			for (Map.Entry<Integer, Vehicle> entry : carSlotList.entrySet()) {
				if (entry.getValue().getColor().equalsIgnoreCase(consoleInput[1])) {
					System.out.print(entry.getValue().getRegistrationNumber() + " ");
				}
			}
		} else {
			System.err.println("Not found");
		}
	}

	public static void getSlotNumberForGivenVehicleColor(String[] consoleInput) {
		if (carSlotList.isEmpty() != true) {
			for (Map.Entry<Integer, Vehicle> entry : carSlotList.entrySet()) {
				if (entry.getValue().getColor().equalsIgnoreCase(consoleInput[1])) {
					System.out.print(entry.getKey() + " ");
				}
			}
		} else {
			System.err.println("Not found");
		}
	}

	public static void getSlotNumberForGivenVehicleRegNumber(String[] consoleInput) {
		if (carSlotList.isEmpty() != true) {
			for (Map.Entry<Integer, Vehicle> entry : carSlotList.entrySet()) {
				if (entry.getValue().getRegistrationNumber().equalsIgnoreCase(consoleInput[1])) {
					System.out.print(entry.getKey() + " ");
				}

			}
		} else {
			System.err.println("Not found");
		}
	}

}
