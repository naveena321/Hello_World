# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 14:30:57 2019

@author: srn
"""

import pandas as pd
from sklearn.preprocessing import Imputer
df1=pd.read_csv("expr.csv")
print(df1.info())
imp = Imputer(missing_values="NaN",strategy='mean',axis=0)
imr=imp.fit(df1)
df_imp=imp.transform(df1.values)
print(df_imp)
