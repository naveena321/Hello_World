package com.parkinglot.util;

import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.parkinglot.dao.Vehicle;
import com.parkinglot.factory.VehicleFactory;

public class ParkingUtility {
	private static Set<Integer> emptySlotList = new TreeSet<>();
	private static Map<Integer, Vehicle> vehicleSlotList;
	private static Vehicle vehicle;
	private static int lotSize;
	private static int j = 1;
	private static Integer slotNumber;
	private static int temp;
	private static boolean parked = true;
	private static String s = "";
	public static void createParkingLot(String[] consoleInput) {
		lotSize = Integer.parseInt(consoleInput[1]);
		vehicleSlotList = new TreeMap<>();
		System.out.println("Created a parking lot with " + lotSize + " slots");
	}

	public static void parkVehicle(String[] consoleInput) {
		vehicle = VehicleFactory.getVehicle("car", consoleInput[1], consoleInput[2]);
		parked = true;
		checkGivenVehicleRegNumberExistOrNoT(consoleInput);
		try {
			temp = emptySlotList.iterator().next();
		} catch (NoSuchElementException e) {
		}

		if (vehicleSlotList.get(j) == null && j <= lotSize) {
			if (parked) {
				vehicleSlotList.put(j, vehicle);
				System.out.println("Allocated slot number: " + j);
				j++;
			}
		} else if (vehicleSlotList.get(temp) == null && temp <= lotSize) {
			vehicleSlotList.put(temp, vehicle);
			emptySlotList.remove(temp);
			System.out.println("Allocated slot number: " + temp);
		} else {
			System.err.println("Sorry, parking lot is full");
		}
	}

	public static void leaveVehicle(String[] consoleInput) {
		slotNumber = Integer.parseInt(consoleInput[1]);
		if (vehicleSlotList.get(slotNumber) != null && slotNumber<vehicleSlotList.size()) {
			vehicleSlotList.remove(slotNumber);
			emptySlotList.add(slotNumber);
			System.out.println("Slot number " + slotNumber + " is free");
		}
		else {
			System.err.println("there is no car parked at a given slot number");
		}
	}

	public static void getVehicleStatus(String[] consoleInput) {
		if (vehicleSlotList.isEmpty() != true) {
			System.err.println("Slot No. " + " Registration No." + " Color");
			System.out.println("                                      ");
			for (Map.Entry<Integer, Vehicle> entry : vehicleSlotList.entrySet()) {
				System.out.println(entry.getKey() + "" + entry.getValue());
			}
		} else {
			System.err.println("Not found");
		}
	}

	public static void getRegNumberForGivenVehicleColor(String[] consoleInput) {
		if (vehicleSlotList.isEmpty() != true) {
			for (Map.Entry<Integer, Vehicle> entry : vehicleSlotList.entrySet()) {
				if (entry.getValue().getColor().equalsIgnoreCase(consoleInput[1])) {
					// System.out.print(entry.getValue().getRegistrationNumber() + " ");
					s = s + entry.getValue().getRegistrationNumber() + ", ";
				}
			}
			System.out.println(s.substring(0, s.length() - 2));
		} else {
			System.err.println("Not found");
		}
	}

	public static void getSlotNumberForGivenVehicleColor(String[] consoleInput) {
		if (vehicleSlotList.isEmpty() != true) {
			s="";
			boolean found = false;
			for (Map.Entry<Integer, Vehicle> entry : vehicleSlotList.entrySet()) {
				if (entry.getValue().getColor().equalsIgnoreCase(consoleInput[1])) {
					//System.out.print(entry.getKey() + " ");
					s = s + entry.getKey() + ", ";
					found = true;
				}
			}
			System.out.println(s.substring(0, s.length() - 2));
			if (!found) {
				System.err.println("Not Found " + consoleInput[1]);
			}
		} else {
			System.err.println("Not found");
		}
	}

	public static void getSlotNumberForGivenVehicleRegNumber(String[] consoleInput) {
		boolean found = false;
		if (vehicleSlotList.isEmpty() != true) {
			for (Map.Entry<Integer, Vehicle> entry : vehicleSlotList.entrySet()) {
				if (entry.getValue().getRegistrationNumber().equalsIgnoreCase(consoleInput[1])) {
					System.out.println(entry.getKey() + " ");
					found = true;
					parked = false;
				}

			}
			if (!found) {
				System.err.println("Not Found " + consoleInput[1]);
			}
		} else {
			System.err.println("Not found");
		}
	}

	private static void checkGivenVehicleRegNumberExistOrNoT(String[] consoleInput) {
		if (vehicleSlotList.isEmpty() != true) {
			for (Map.Entry<Integer, Vehicle> entry : vehicleSlotList.entrySet()) {
				if (entry.getValue().getRegistrationNumber().equalsIgnoreCase(consoleInput[1])) {
					System.err.println("The given RegisteredNumber vehicle is already parked at the slot number:"+entry.getKey());
					parked = false;
				}

			}
		}
	}

}
