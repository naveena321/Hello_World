# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 17:09:08 2019

@author: srn
"""

import numpy as np
from sklearn.ensemble import RandomForestClassifier
feat_labels = wine.columns[1:]
forest = RandomForestClassifier(n_estimators=100,
                                random_state=0,
                                n_jobs=-1)
# =============================================================================
# X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=0)
# =============================================================================

# =============================================================================
# sc=StandardScaler()
# X_train_std = sc.fit_transform(X_train)
# X_test_std= sc.transform(X_test)
# lr=LogisticRegression(C=1)
# lr.fit(X_train,y_train)
# y_pred = lr.predict(X_test)
# print("misclassification",(y_pred !=y_test).sum())
# =============================================================================

forest.fit(X_train_std,y_train)

importances = forest.feature_importances_
indices = np.argsort(importances)[::-1]

for f in range(X_train_std.shape[1]):
    print("%2d%-*s %f" %(f+1,10,
                         feat_labels[indices[f]],
                         importances[indices[f]]))
