# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 14:52:33 2019

@author: srn
"""

import pandas as pd
import numpy as np
s1=pd.Series([7.4,5.7,6.3,4.9],
             index=['a','f','h','z'])
s2=pd.Series([-2.1,8.4,9.1,-6.1,7.9],
             index=['a','g','t','y','w'])
print(s1+s2)
df1=pd.DataFrame(np.arange(12).reshape((3,4)),
                 columns = list('abcd'))
print(df1)
df2=pd.DataFrame(np.arange(20).reshape((4,5)),
                 columns = list('abcde'))
print(df1.add(df2))
print(df1.add(df2,fill_value=0))
