package com.parkinglot.input_validation;
/**
 * @version 1.0
 * @author srn
 */
public class ValidateInput {

	/**
	 * @param inputFromConsole  read from user at runtime.
	 * @return returns the <a>boolean</a> value <strong>true</strong> if the input format is correct or returns false.
	 * @exception throws <strong>ArrayIndexOutOfBoundException</strong> if the input length is incorrect than the expected input length
	 */
	public static boolean validateParkingLotCreator(String[] inputFromConsole) {
		try {
			Integer.parseInt(inputFromConsole[1]);
		} catch (NumberFormatException e) {
			System.err.println("Invalid Input Format");
			return false;
		}
		if (inputFromConsole.length == 2) {
			return true;
		} else {
			System.err.println("Invalid Input Format");
			return false;
		}

	}

	/**
	 * @param inputFromConsole A String input read from console
	 * @return True if vehicle is not parked at the parking slot else returns false.
	 */
	public static boolean validateParkingVehicle(String[] inputFromConsole) {
		String[] regNum = inputFromConsole[1].split("-");
		try {
			Integer.parseInt(regNum[1]);
			Integer.parseInt(regNum[3]);
		} catch (NumberFormatException e) {
			System.err.println("Invalid Input Format");
			return false;
		}
		return true;

	}
	/**
	 * @param inputFromConsole A String input read from console
	 * @return True if vehicle is departed at the parking slot else returns false.
	 */
	public static boolean validateMovingVehicle(String[] inputFromConsole) {
		try {
			Integer.parseInt(inputFromConsole[1]);
		} catch (NumberFormatException e) {
			System.err.println("Invalid Input Format");
			return false;
		} catch (Exception e) {
			System.err.println("Invalid Input Format");
			return false;
		}
		if (inputFromConsole.length == 2) {
			return true;
		} else {
			System.err.println("Invalid Input Format");
			return false;
		}
	}

}
