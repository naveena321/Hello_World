package com.parkinglot.dao;

public class Car implements Vehicle {

	private String color;
	private String registrationNumber;

	public Car(String registrationNumber, String color) {
		super();
		this.color = color;
		this.registrationNumber = registrationNumber;
	}

	@Override
	public String toString() {
		return "        " + registrationNumber + "    " + color;
	}

	@Override
	public String getColor() {
		return this.color;
	}

	@Override
	public String getRegistrationNumber() {
		return this.registrationNumber;
	}
}
