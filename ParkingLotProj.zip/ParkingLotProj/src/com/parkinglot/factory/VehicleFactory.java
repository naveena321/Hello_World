package com.parkinglot.factory;

import com.parkinglot.dao.Car;
import com.parkinglot.dao.Vehicle;

public class VehicleFactory {
	
	public static Vehicle getVehicle(String type,String registrationNumber,String color){
		if("CAR".equalsIgnoreCase(type)) return new Car(registrationNumber,color);
		//else if("BIKE".equalsIgnoreCase(type)) return new BIKE(color, registrationNumber);
		
		return null;
	}
}
