# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 16:27:25 2019

@author: srn
"""

import pandas as pd
import numpy as np
left1=pd.DataFrame({'key':['a','b','a','a','b','c'],
                    'value':range(6)})
right1=pd.DataFrame({'group_val': [3.5, 7]}, index=['a', 'b'])
print(pd.merge(left1, right1, left_on='key', right_index=True))
print(pd.merge(left1, right1, left_on='key', right_index=True, how='outer'))
