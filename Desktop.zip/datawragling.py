# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 16:04:36 2019

@author: srn
"""

import pandas as pd
import numpy as np
df1=pd.DataFrame({'key':list('bbacaab'),
                  'data1':range(7)})
df2=pd.DataFrame({'key':list('abd'),
                  'data1':range(3)})
print(pd.merge(df1,df2,on='key',how='outer'))

#df1 = pd.DataFrame({'lkey':list('bbacaab'),
  #                 'data1':range(7)})
#df2 = pd.DataFrame({'rkey':list('abd'),
 #                  'data2':range(3)})
#print(pd.merge(df1,df2,left_on='lkey',right_on='rkey',how='outer')) 
df3=pd.DataFrame({'st':['mh','mh','tn'],
                   'fg':['pd','sc','pd'],
                   'qty':[12,11,5]})
df4=pd.DataFrame({'st':['mh','mh','tn','tn'],
                   'fg':['pd','pd','pd','sc'],
                   'qty':[11,9,10,8]})
print(pd.merge(df3,df4,on=['st','fg']))
x=np.array([0,1,2])
y=pd.merge(df3,df4,on=['st','fg']).iloc[:,2].values