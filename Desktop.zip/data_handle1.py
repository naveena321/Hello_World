# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 14:42:56 2019

@author: srn
"""

import pandas as pd
from sklearn.preprocessing import Imputer,LabelEncoder,OneHotEncoder
tshirts=pd.DataFrame([['g','M',100,'adidas'],
                ['b','L',400,'puma'],
                ['k','XL',200,'adidas']])
tshirts.columns=['color','size','price','brand']
sizetonum={'XL':3,'L':2,'M':1}
brtonum={'puma':1,'adidas':2}
tshirts['size'] = tshirts['size'].map(sizetonum)
tshirts['brand'] = tshirts['brand'].map(brtonum)
print(tshirts)
X=tshirts.iloc[:,:3].values
cle = LabelEncoder()
X[:,0] = cle.fit_transform(X[:,0])
print(X)
ohe=OneHotEncoder(categorical_features=[0])
oh=ohe.fit_transform(X).toarray()
print(oh)