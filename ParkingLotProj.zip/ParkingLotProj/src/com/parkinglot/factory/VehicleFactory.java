package com.parkinglot.factory;

import com.parkinglot.dao.Car;
import com.parkinglot.dao.Vehicle;

/**
 * @version 1.0
 * @author srn
 *
 */
public class VehicleFactory {

	/**
	 * 
	 * @param type checks the given vehicle is of vehicle type or not.
	 * @param registrationNumber A string representing the vehicle registrationNumber.
	 * @param color A string representing the vehicle color.
	 * @return new vehicle with its details.
	 */
	public static Vehicle getVehicle(String type, String registrationNumber, String color) {
		if ("CAR".equalsIgnoreCase(type))
			return new Car(registrationNumber, color);
		/*else if ("BIKE".equalsIgnoreCase(type))
			return new Bike(registrationNumber, color);*/

		return null;
	}
}
