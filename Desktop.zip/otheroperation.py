# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 17:26:56 2019

@author: srn
"""
import pandas as pd
import numpy as np
df = pd.DataFrame({'key1' : ['a', 'a', 'b', 'b', 'a'],
                   'key2' : ['one', 'two', 'one', 'two', 'one'],
                   'data1' : np.random.randn(5),
                   'data2' : np.random.randn(5)})
pieces = dict(list(df.groupby('key1')))
print(pieces['b'])
grouped = df.groupby(df.dtypes, axis=1)
print(dict(list(grouped)))
