# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 17:45:08 2019

@author: srn
"""

from numpy import array,mean,cov
from sklearn.decomposition import PCA
# =============================================================================
# from numpy.linalg import eig
# A= array([[1,2],[3,4],[5,6]])
# print(A)
# M=mean(A.T,axis=1)
# print("mean:",M)
# C=A-M
# print(C)
# print(C.T)
# V=cov(C.T)
# print(V)
# values,vectors = eig(V)
# p=vectors.T.dot(C.T)
# print(p.T)
# =============================================================================
A= array([[1,2],[3,4],[5,6]])
print(A)
pca=PCA(2)
pca.fit(A)
print(pca.components_)
print(pca.explained_variance_)
B=pca.transform(A)
print(B)