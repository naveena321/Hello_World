# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 13:56:20 2019

@author: srn
"""
import numpy as np
import matplotlib.pyplot as plt
n = 256 
X = np.linspace(-np.pi, np.pi, n, endpoint=True) 
Y = np.sin(2 * X) 
plt.plot(X, Y + 1, color='blue', alpha=1.00) 
plt.plot(X, Y - 1, color='blue', alpha=1.00) 
