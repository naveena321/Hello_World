package com.parkinglot.dao;

/**
 * @version	1.0
 * @author srn
 *
 */
public interface Vehicle {

	/** Gets the vehicle color.
	 * @return A string representing the vehicle color.
	*/
	public String getColor();

	/** Gets the vehicle RegistrationNumber.
	 * @return A string representing the vehicle RegistrationNumber.
	*/
	public String getRegistrationNumber();
}
