package com.parkinglot.input_validation;

public class ValidateInput {

	public static boolean validateParkingLotCreator(String[] inputFromConsole) {
		try {
			Integer.parseInt(inputFromConsole[1]);
		} catch (NumberFormatException e) {
			System.err.println("Invalid Input Format");
			return false;
		}
		if (inputFromConsole.length == 2) {
			return true;
		} else {
			System.err.println("Invalid Input Format");
			return false;
		}

	}
	public static boolean validateParkingVehicle(String[] inputFromConsole) {
		String[] regNum=inputFromConsole[1].split("-");
		try {
			Integer.parseInt(regNum[1]);
			Integer.parseInt(regNum[3]);
		}catch (NumberFormatException e) {
			System.err.println("Invalid Input Format");
			return false;
		}
		return true;
		
	}
	public static boolean validateMovingVehicle(String[] inputFromConsole) {
		try {
			Integer.parseInt(inputFromConsole[1]);
		} catch (NumberFormatException e) {
			System.err.println("Invalid Input Format");
			return false;
		}
		catch (Exception e) {
			System.err.println("Invalid Input Format");
			return false;
		}
		if (inputFromConsole.length == 2) {
			return true;
		} else {
			System.err.println("Invalid Input Format");
			return false;
		}
	}
	

}
