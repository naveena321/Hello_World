# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 10:25:58 2019

@author: srn
"""

from sklearn import datasets
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
import pandas as pd
iris=datasets.load_iris()
print(iris)
# =============================================================================
# X=iris.data[50:150,[2,3]]
# y=iris.target[50:150]
# =============================================================================
X=iris.data
y=iris.target
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=0)
ppn=Perceptron(n_iter=20,eta0=0.01,random_state=0)
ppn.fit(X_train,y_train)
y_pred=ppn.predict(X_test)
print("------------")
print("misclassified",(y_test != y_pred).sum())
# =============================================================================
# new_data = pd.DataFrame([{'petal_length(cm)':4.7,
#                           'petal_width(cm)':1.4},
#                          {'petal_length(cm)':5.1,
#                           'petal_width(cm)':1.8}])
# new_data = new_data[['petal_length(cm)',
#                           'petal_width(cm)']]
# new_pred = ppn.predict(new_data)
# new_data['label']=new_pred
# print(new_data)
# =============================================================================
