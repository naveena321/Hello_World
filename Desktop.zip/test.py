# -*- coding: utf-8 -*-
"""
Created on Mon Jan 14 14:24:15 2019

@author: srn
"""
import numpy as np
a=np.array([12,3,6,8,9])
b=np.array([2,5,8,34,5])
c=a-b
print(c)
