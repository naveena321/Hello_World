# -*- coding: utf-8 -*-
"""
Created on Fri Jan 18 12:43:38 2019

@author: srn
"""

from sklearn import datasets
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
wine=pd.read_csv("wine.data",header=None)
y = wine.iloc[:,0].values[:130]
X=wine.iloc[:,1:].values[:130]
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=0)

dtc=DecisionTreeClassifier(max_depth=6,random_state=0)
dtc.fit(X_train,y_train)
y_pred=dtc.predict(X_test)
print("misclassification",(y_pred !=y_test).sum())