# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 15:25:25 2019

@author: srn
"""

import pandas as pd
import numpy as np
obj = pd.Series([7,-5,7,4,2,0,4])
print(obj.rank())
#print(obj.rank(method='first'))
#print(obj.rank(ascending=False))
print(obj.rank(ascending=False,method='max'))