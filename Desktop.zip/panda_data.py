# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 14:01:07 2019

@author: srn
"""
#import os
import pandas as pd
s1=pd.Series([12,14,11,17,34,56],index=['mh','kp','gf','ln','ad','xe'])
print(s1)
print(s1.describe())#describes the mean std,min,max etc
print(s1.reindex(['kp','gf','ln','ad','xe','mh']))
print(s1['kp'])

df1=pd.DataFrame({'popn':[12,14,11,17,34,56],
                  'state':['mh','kp','gf','ln','ad','xe'],
                  'ag':['fr','jk','yr','df','io','dsf']})
print(df1)
df1.to_csv("first.csv")
df1=df1.set_index('state')
print(df1)
#if os.path.exists('//svvin203rmz0001.global.anz.com/srn$/Desktop'):
#   df1.to_csv("//svvin203rmz0001.global.anz.com/srn$/Desktop/second.csv")
    
s1=pd.Series(['mh','kp','gf'],
             index=[0,5,10])
print(s1.reindex(range(15),method='ffill',limit=2))
#print(s1.reindex(range(15),method='bfill',limit=2)) backward fill
print(df1.loc['mh'])
print(df1.iloc[:,1].values)
#print(df1['ag']) to proint particular column
print(df1[(df1['popn']>10)&(df1['popn']<15)])