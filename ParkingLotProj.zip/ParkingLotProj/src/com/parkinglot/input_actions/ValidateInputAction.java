package com.parkinglot.input_actions;

import com.parkinglot.input_model.ParkingAction;
import com.parkinglot.input_validation.ValidateInput;
import com.parkinglot.util.ParkingUtility;

public class ValidateInputAction {

	public static void validateAction(String[] consoleInput) {

		if (ParkingAction.create_parking_lot.name().equalsIgnoreCase(consoleInput[0])) {
			boolean res = ValidateInput.validateParkingLotCreator(consoleInput);
			if (res == true) {
				ParkingUtility.createParkingLot(consoleInput);
			}
		} else if (ParkingAction.park.name().equalsIgnoreCase(consoleInput[0])) {
			boolean res = ValidateInput.validateParkingVehicle(consoleInput);
			if (res == true) {
				ParkingUtility.parkVehicle(consoleInput);
			}
		} else if (ParkingAction.leave.name().equalsIgnoreCase(consoleInput[0])) {
			boolean res = ValidateInput.validateMovingVehicle(consoleInput);
			if (res == true) {
				ParkingUtility.leaveVehicle(consoleInput);
			}
		} else if (ParkingAction.status.name().equalsIgnoreCase(consoleInput[0])) {
			ParkingUtility.getVehicleStatus(consoleInput);
		} else if (ParkingAction.registration_numbers_for_cars_with_colour.name().equalsIgnoreCase(consoleInput[0])) {
			ParkingUtility.getRegNumberForGivenVehicleColor(consoleInput);
		} else if (ParkingAction.slot_numbers_for_cars_with_colour.name().equalsIgnoreCase(consoleInput[0])) {
			ParkingUtility.getSlotNumberForGivenVehicleColor(consoleInput);
		} else if (ParkingAction.slot_number_for_registration_number.name().equalsIgnoreCase(consoleInput[0])) {
			ParkingUtility.getSlotNumberForGivenVehicleRegNumber(consoleInput);
		} else {
			System.err.print("Invalid Input");
		}
	}
}
