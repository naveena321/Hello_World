# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 16:46:02 2019

@author: srn
"""
import pandas as pd
import numpy as np
a = pd.Series([np.nan, 2.5, np.nan, 3.5, 4.5, np.nan],
           index=['f', 'e', 'd', 'c', 'b', 'a'])
b = pd.Series(np.arange(len(a), dtype=np.float64),
           index=['f', 'e', 'd', 'c', 'b', 'a'])
b[-1] = np.nan
print(b[:-2].combine_first(a[2:]))
print(a[2:].combine_first(b[:-2]))
