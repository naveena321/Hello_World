# -*- coding: utf-8 -*-
"""
Created on Sun Jan 13 15:04:32 2019

@author: srn
"""

import pandas as pd
import numpy as np
frame=pd.DataFrame(np.random.randn(4,3),
                   columns=list('bde'),
                   index=['utah','jhv','hjv','qw'])
#print(frame)
np.abs(frame)
print(np.abs(frame))
f=lambda x:x.max()-x.min()
print(frame.apply(f))
frame.apply(f,axis=1)
format=lambda x:'%.2f'%x
frame.applymap(format)
print(frame.applymap(format))
frame['e'].map(format)

obj=pd.Series(['d','f','e','s','z','w','b'])
uniques=obj.unique()
#to get the value frequencies
obj.value_counts()
mask=obj.isin(['b','c'])#isin is responsible for vectorized value