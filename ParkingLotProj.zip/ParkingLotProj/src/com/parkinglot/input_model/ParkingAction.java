package com.parkinglot.input_model;

public enum ParkingAction {

	create_parking_lot, park, leave, status, registration_numbers_for_cars_with_colour, slot_numbers_for_cars_with_colour, slot_number_for_registration_number
}
