package com.parkinglot.dao;

/**
 * @version 1.0
 * @author srn
 *
 */
public class Car implements Vehicle {

	private String color;
	private String registrationNumber;
	
	/**
	 * Creates an vehicle with the specified details.
	 * @param registrationNumber A string representing the vehicle registrationNumber
	 * @param color A string representing the vehicle color
	 */
	public Car(String registrationNumber, String color) {
		super();
		this.color = color;
		this.registrationNumber = registrationNumber;
	}

/**
 * Print the given vehicle with details.
 */
	@Override
	public String toString() {
		return "        " + registrationNumber + "    " + color;
	}
	
	/** Gets the vehicle color.
	 * @return A string representing the vehicle color.
	*/
	@Override
	public String getColor() {
		return this.color;
	}

	/** Gets the vehicle RegistrationNumber.
	 * @return A string representing the vehicle RegistrationNumber.
	*/
	@Override
	public String getRegistrationNumber() {
		return this.registrationNumber;
	}
}
