package com.parkinglot.parking_creator;

import java.util.Scanner;

import com.parkinglot.input_actions.ValidateInputAction;

public class ParkingCreator {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String[] consoleInput;
		do {
			consoleInput = sc.nextLine().split(" ");
			ValidateInputAction.validateAction(consoleInput);
		} while (!(consoleInput.length <= 0));

	}
}
